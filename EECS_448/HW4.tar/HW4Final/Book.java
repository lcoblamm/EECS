/*
 * EECS 448
 * HW 4
 * 2014.11.19
 * Lynne Lammers, Christine Perinchery, Roxanne Calderon
 * Book.java
 */

public class Book {
	private String title;
	private String author;
	private double price;
	private String category; 
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String t) {
		title = t;
	}	
	public String getAuthor() {
		return author;
	}	
	public void setAuthor(String a) {
		author = a;
	}	
	public double getPrice(){
		return price;
	}	
	public void setPrice(double p) {
		price = p;
	}
	public String getCategory() {
		return category;
	}	
	public void setCategory(String c) {
		category = c;
	}
}
